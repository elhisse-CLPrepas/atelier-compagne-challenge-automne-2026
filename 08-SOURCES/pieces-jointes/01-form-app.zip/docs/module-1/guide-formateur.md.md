# Guide du formateur - Module 1

## Objectifs pédagogiques
1. **Expliquer l'IA** à un public non technique en 60 secondes
2. **Distinguer 5 types de tâches** IA et choisir la bonne demande
3. **Appliquer la règle** : humain valide avant diffusion

## Préparation matérielle
- Durée : 90 minutes
- Participants : 6-12 personnes
- Matériel :
  - Ordinateur + projecteur
  - Accès à ChatGPT/Claude/Copilot
  - Papier + stylos pour les participants
  - Template de prompts à distribuer

## Déroulé détaillé

### 0-10 min : Cadrage
- Présentation du programme
- Règles de sécurité : anonymisation, validation humaine
- Objectif mesurable de la séance
- Tour de table rapide

### 10-30 min : Concepts clés
- Les 5 types de tâches IA (recherche, rédaction, raisonnement, extraction, classification)
- Exemples concrets pour chaque type
- Échanges avec les participants

### 30-50 min : Démonstration
- Cas pratique : triage de tickets support
- Montrer la structure d'un prompt efficace
- Expliquer la validation humaine

### 50-80 min : Pratique en binômes
- Distribution des cas anonymisés
- Travail en binômes avec template
- Assistance individualisée

### 80-90 min : Débrief
- Présentation des livrables
- Retour d'expérience
- Plan d'actions 7 jours
- Évaluation rapide

## Gestion des difficultés

### Participants anxieux
- Réduire le périmètre
- Donner des templates prêts à l'emploi
- Valider rapidement une première réussite

### Participants sceptiques
- Faire un test avant/après chronométré
- Comparer qualité manuelle vs assistée
- Garder uniquement ce qui améliore

### Participants surconfiants
- Ajouter des contraintes supplémentaires
- Exiger reproductibilité et traçabilité
- Noter avec la grille qualité

## Évaluation
- Quiz de 5 questions en fin de module
- Observation pendant la pratique
- Qualité du livrable produit
- Auto-évaluation des participants

## Ressources complémentaires
- [Lien vers les slides]()
- [Lien vers les templates]()
- [Lien vers la FAQ]()