# Slides Module 1

## Slide 1 : Titre
**Formation IA 2026 - Module 1**
Fondations IA en entreprise

## Slide 2 : Objectifs
- Expliquer l'IA en 60 secondes
- Distinguer 5 types de tâches
- Appliquer : humain valide avant diffusion

## Slide 3 : Règles de sécurité
1. Anonymiser les données
2. Valider humainement avant diffusion
3. Formater pour vérification
4. Documenter les hypothèses

## Slide 4 : Les 5 types de tâches
1. **Recherche** : informations vérifiables
2. **Rédaction** : textes professionnels
3. **Raisonnement** : décisions structurées
4. **Extraction** : données tabulaires
5. **Classification** : tri et étiquetage

## Slide 5 : Structure d'un prompt
- Contexte : situation, enjeux
- Objectif : résultat attendu
- Données : autorisées/interdites
- Contraintes : règles à respecter
- Format : structure imposée

## Slide 6 : Cas pratique
**Tri de tickets support**
- 30 messages/jour
- Objectif : standardiser sans exposer
- Résultat : classification + réponse + procédure

## Slide 7 : Validation humaine
Grille en 4 points :
1. Faits vérifiés ?
2. Confidentialité respectée ?
3. Ton approprié ?
4. Action claire ?

## Slide 8 : Exercice
**En binômes** :
1. Choisir un micro-cas réel
2. Anonymiser les données
3. Écrire un prompt complet
4. Tester et valider

## Slide 9 : Plan 7 jours
Jour 1 : Identifier 1 cas réel
Jour 2 : Créer 1 template
Jour 3 : Tester 1 itération
Jour 4 : Appliquer 1 contrôle
Jour 5 : Rédiger 1 SOP
Jour 6 : Partager 1 retour
Jour 7 : Répliquer 1 nouveau cas

## Slide 10 : Questions ?
formation@entreprise.com