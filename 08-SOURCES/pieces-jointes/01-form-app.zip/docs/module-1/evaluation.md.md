# Évaluation Module 1

## Quiz (5 questions)

### Question 1
Quel élément est non négociable dès le départ avec l'IA ?
- [ ] Le style littéraire
- [x] La validation humaine
- [ ] Le nombre de tokens utilisé

### Question 2
Quel type de tâche produit un tableau de champs extraits ?
- [ ] Rédaction
- [x] Extraction
- [ ] Raisonnement

### Question 3
Quelle est la meilleure correction d'une demande floue ?
- [ ] Changer de modèle d'IA
- [x] Ajouter but + contexte + format
- [ ] Demander une réponse plus longue

### Question 4
Quelle pratique réduit le risque de réponses inutiles ?
- [ ] Itérer en changeant 10 paramètres
- [x] Itérer en changeant 1 variable à la fois
- [ ] Copier-coller sans relire

### Question 5
La classification sert principalement à…
- [ ] Écrire un email professionnel
- [x] Trier et prioriser des éléments
- [ ] Faire une recherche web

## Cas pratique (10 minutes)

**Consigne** : Traitez le message anonymisé suivant :
