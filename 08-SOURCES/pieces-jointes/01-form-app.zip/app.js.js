class FormationIAApp {
    constructor() {
        this.modules = [];
        this.currentModule = null;
        this.userProgress = {};
        this.userNotes = {};
        this.bookmarks = new Set();
        
        // Éléments DOM
        this.elements = {
            modulesList: document.getElementById('modulesList'),
            moduleContent: document.getElementById('moduleContent'),
            moduleTitle: document.getElementById('moduleTitle'),
            moduleDesc: document.getElementById('moduleDesc'),
            moduleTags: document.getElementById('moduleTags'),
            moduleStatus: document.getElementById('moduleStatus'),
            docsList: document.getElementById('docsList'),
            globalProgress: document.getElementById('globalProgress'),
            progressText: document.getElementById('progressText'),
            progressDetail: document.getElementById('progressDetail'),
            moduleProgressBar: document.getElementById('moduleProgressBar'),
            btnPrev: document.getElementById('btnPrev'),
            btnNext: document.getElementById('btnNext'),
            btnTheme: document.getElementById('btnTheme'),
            btnToggleDocs: document.getElementById('btnToggleDocs'),
            btnCloseDocs: document.getElementById('btnCloseDocs'),
            btnBookmark: document.getElementById('btnBookmark'),
            btnNotes: document.getElementById('btnNotes'),
            btnComplete: document.getElementById('btnComplete'),
            btnResetProgress: document.getElementById('btnResetProgress'),
            btnSaveProgress: document.getElementById('btnSaveProgress'),
            currentModuleIndex: document.getElementById('currentModuleIndex'),
            totalModules: document.getElementById('totalModules'),
            searchInput: document.getElementById('searchInput')
        };

        this.init();
    }

    async init() {
        // Charger les données
        await this.loadModules();
        this.loadUserData();
        
        // Initialiser l'interface
        this.renderModulesList();
        this.setupEventListeners();
        this.setupTheme();
        
        // Charger le premier module
        if (this.modules.length > 0) {
            await this.loadModule(this.modules[0].id);
        }
        
        // Mettre à jour les compteurs
        this.elements.totalModules.textContent = this.modules.length;
        
        // Définir les couleurs CSS
        this.setCSSVariables();
    }

    setCSSVariables() {
        // Définir les variables CSS pour l'animation du cercle de progression
        const root = document.documentElement;
        root.style.setProperty('--progress', '0');
    }

    async loadModules() {
        try {
            const response = await fetch('modules.json');
            const data = await response.json();
            this.modules = data.modules;
        } catch (error) {
            console.error('Erreur lors du chargement des modules:', error);
            // Fallback aux données intégrées
            this.modules = this.getDefaultModules();
        }
    }

    getDefaultModules() {
        return [
            {
                id: 'module-1',
                week: 1,
                title: 'Fondations IA en entreprise',
                description: 'Poser le cadre. Comprendre l'IA sans jargon. Installer une méthode reproductible.',
                duration: '90 minutes',
                version: 'v1.1',
                tags: ['fondations', 'méthode', 'sécurité'],
                objectives: [
                    'Expliquer l'IA à un public non technique en 60 secondes',
                    'Distinguer 5 types de tâches IA et choisir la bonne demande',
                    'Appliquer la règle : humain valide avant diffusion'
                ]
            },
            {
                id: 'module-2',
                week: 2,
                title: 'Prompt engineering opérationnel',
                description: 'Méthode en 6 blocs. Production de bibliothèque de prompts.',
                duration: '90 minutes + 60 minutes',
                version: 'v1.0',
                tags: ['prompt', 'qualité', 'bibliothèque']
            },
            {
                id: 'module-3',
                week: 3,
                title: 'Intégration IA dans les processus',
                description: 'Automatiser les workflows métiers avec contrôle qualité intégré.',
                duration: '120 minutes',
                version: 'v1.0',
                tags: ['workflow', 'automatisation', 'intégration']
            },
            {
                id: 'module-4',
                week: 4,
                title: 'Gouvernance et éthique IA',
                description: 'Cadre légal, éthique et gouvernance des projets IA en entreprise.',
                duration: '90 minutes',
                version: 'v1.0',
                tags: ['gouvernance', 'éthique', 'RGPD']
            },
            {
                id: 'module-5',
                week: 5,
                title: 'Pédagogie formateur et design de formation',
                description: 'Concevoir et animer des modules internes 90 minutes.',
                duration: '90 minutes + 60 minutes',
                version: 'v1.0',
                tags: ['pédagogie', 'formation', 'animation']
            },
            {
                id: 'module-6',
                week: 6,
                title: 'Projet final et certification',
                description: 'Mise en œuvre complète et validation des compétences.',
                duration: '120 minutes',
                version: 'v1.0',
                tags: ['projet', 'certification', 'validation']
            },
            {
                id: 'annexe',
                week: 7,
                title: 'Annexes et ressources',
                description: 'Toutes les références, templates et outils complémentaires',
                version: 'v1.0',
                tags: ['ressources', 'templates', 'références'],
                isAnnex: true
            }
        ];
    }

    loadUserData() {
        // Charger la progression
        const savedProgress = localStorage.getItem('formation-ia-progress');
        if (savedProgress) {
            this.userProgress = JSON.parse(savedProgress);
        }

        // Charger les notes
        const savedNotes = localStorage.getItem('formation-ia-notes');
        if (savedNotes) {
            this.userNotes = JSON.parse(savedNotes);
        }

        // Charger les bookmarks
        const savedBookmarks = localStorage.getItem('formation-ia-bookmarks');
        if (savedBookmarks) {
            this.bookmarks = new Set(JSON.parse(savedBookmarks));
        }
    }

    saveUserData() {
        localStorage.setItem('formation-ia-progress', JSON.stringify(this.userProgress));
        localStorage.setItem('formation-ia-notes', JSON.stringify(this.userNotes));
        localStorage.setItem('formation-ia-bookmarks', JSON.stringify(Array.from(this.bookmarks)));
    }

    async loadModule(moduleId) {
        this.currentModule = this.modules.find(m => m.id === moduleId);
        
        if (!this.currentModule) {
            this.showError('Module non trouvé');
            return;
        }

        // Mettre à jour l'en-tête
        this.updateModuleHeader();

        // Afficher l'état de chargement
        this.elements.moduleContent.innerHTML = `
            <div class="loading-state">
                <div class="spinner">
                    <div class="spinner-circle"></div>
                </div>
                <p>Chargement du module...</p>
            </div>
        `;

        try {
            // Charger le contenu HTML
            const response = await fetch(`data/${moduleId}.html`);
            if (!response.ok) throw new Error('Fichier non trouvé');
            
            const content = await response.text();
            this.elements.moduleContent.innerHTML = content;

            // Initialiser les fonctionnalités interactives
            this.initModuleFeatures();

            // Mettre à jour la progression
            this.updateProgressDisplay();

            // Charger les documents
            this.loadModuleDocs();

            // Mettre à jour l'interface
            this.updateModuleListSelection();
            this.updateNavigationButtons();
            this.updateBookmarkButton();

            // Mettre à jour l'index
            const currentIndex = this.modules.findIndex(m => m.id === moduleId) + 1;
            this.elements.currentModuleIndex.textContent = currentIndex;

            // Déclencher un événement personnalisé
            window.dispatchEvent(new CustomEvent('moduleChanged', {
                detail: { moduleId }
            }));

            this.showToast('Module chargé', 'success');
        } catch (error) {
            console.error('Erreur lors du chargement du module:', error);
            this.elements.moduleContent.innerHTML = `
                <div class="content-section">
                    <h2>${this.currentModule.title}</h2>
                    <p>${this.currentModule.description}</p>
                    <div class="card-grid">
                        <div class="content-card">
                            <div class="card-header">
                                <div class="card-icon">
                                    <i class="fas fa-bullseye"></i>
                                </div>
                                <h3 class="card-title">Objectifs</h3>
                            </div>
                            <div class="card-body">
                                <ul>
                                    ${(this.currentModule.objectives || []).map(obj => `<li>${obj}</li>`).join('')}
                                </ul>
                            </div>
                        </div>
                        <div class="content-card">
                            <div class="card-header">
                                <div class="card-icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <h3 class="card-title">Durée</h3>
                            </div>
                            <div class="card-body">
                                <p>${this.currentModule.duration || 'Non spécifiée'}</p>
                            </div>
                        </div>
                        <div class="content-card">
                            <div class="card-header">
                                <div class="card-icon">
                                    <i class="fas fa-tags"></i>
                                </div>
                                <h3 class="card-title">Tags</h3>
                            </div>
                            <div class="card-body">
                                <div class="tags-container">
                                    ${(this.currentModule.tags || []).map(tag => `<span class="tag">${tag}</span>`).join('')}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="alert">
                        <i class="fas fa-info-circle"></i>
                        <p>Le contenu détaillé du module sera disponible prochainement.</p>
                    </div>
                </div>
            `;
            this.showToast('Contenu de démonstration chargé', 'warning');
        }
    }

    updateModuleHeader() {
        if (!this.currentModule) return;

        this.elements.moduleTitle.textContent = this.currentModule.title;
        this.elements.moduleDesc.textContent = this.currentModule.description;
        
        // Mettre à jour les tags
        let tagsHTML = '';
        if (!this.currentModule.isAnnex) {
            tagsHTML += `<span class="tag week-tag">Semaine ${this.currentModule.week}</span>`;
        }
        tagsHTML += `<span class="tag version-tag">${this.currentModule.version}</span>`;
        
        // Statut
        const progress = this.userProgress[this.currentModule.id] || { progress: 0 };
        let statusText = 'Non commencé';
        let statusClass = 'info';
        
        if (progress.progress >= 100) {
            statusText = 'Terminé';
            statusClass = 'success';
        } else if (progress.progress > 0) {
            statusText = 'En cours';
            statusClass = 'warning';
        }
        
        tagsHTML += `<span class="tag status-tag" style="background-color: var(--${statusClass}-light); color: var(--${statusClass});">${statusText}</span>`;
        
        this.elements.moduleTags.innerHTML = tagsHTML;
        this.elements.moduleStatus.textContent = statusText;
    }

    initModuleFeatures() {
        // Initialiser les checklists
        this.initChecklists();
        
        // Initialiser les quiz
        this.initQuizzes();
        
        // Initialiser les boutons de copie
        this.initCopyButtons();
        
        // Initialiser les accordéons
        this.initAccordions();
        
        // Initialiser les formulaires
        this.initForms();
    }

    initChecklists() {
        document.querySelectorAll('.checklist input[type="checkbox"]').forEach(checkbox => {
            const checklistId = checkbox.getAttribute('data-checklist-id');
            if (!checklistId) return;

            // Restaurer l'état
            const moduleProgress = this.userProgress[this.currentModule.id] || { checklists: {} };
            checkbox.checked = moduleProgress.checklists[checklistId] || false;

            // Ajouter l'événement
            checkbox.addEventListener('change', (e) => {
                if (!this.currentModule) return;
                
                const progress = this.userProgress[this.currentModule.id] || {
                    progress: 0,
                    checklists: {}
                };
                
                progress.checklists[checklistId] = e.target.checked;
                
                // Calculer la progression
                const checkboxes = document.querySelectorAll('.checklist input[type="checkbox"]');
                const checked = document.querySelectorAll('.checklist input[type="checkbox"]:checked');
                progress.progress = Math.round((checked.length / checkboxes.length) * 100);
                
                this.userProgress[this.currentModule.id] = progress;
                this.saveUserData();
                this.updateProgressDisplay();
                this.updateGlobalProgress();
                
                // Afficher un toast
                if (e.target.checked) {
                    this.showToast('Élément complété', 'success');
                }
            });
        });
    }

    initQuizzes() {
        document.querySelectorAll('.quiz input[type="radio"]').forEach(radio => {
            const quizId = radio.getAttribute('name');
            if (!quizId) return;

            // Restaurer la réponse
            const moduleProgress = this.userProgress[this.currentModule.id] || { quizzes: {} };
            if (moduleProgress.quizzes[quizId] === radio.value) {
                radio.checked = true;
            }

            radio.addEventListener('change', (e) => {
                if (!this.currentModule) return;
                
                const progress = this.userProgress[this.currentModule.id] || {
                    progress: 0,
                    quizzes: {}
                };
                
                progress.quizzes[quizId] = e.target.value;
                this.userProgress[this.currentModule.id] = progress;
                this.saveUserData();
                this.updateProgressDisplay();
                
                this.showToast('Réponse enregistrée', 'info');
            });
        });

        // Boutons de calcul de score
        document.querySelectorAll('.btn-score').forEach(btn => {
            btn.addEventListener('click', () => {
                this.calculateQuizScore(btn.closest('.quiz'));
            });
        });
    }

    calculateQuizScore(quizElement) {
        const questions = quizElement.querySelectorAll('.question');
        let score = 0;
        let total = 0;

        questions.forEach(question => {
            const correctAnswer = question.getAttribute('data-correct');
            const selected = question.querySelector('input:checked');
            
            if (selected && selected.value === correctAnswer) {
                score++;
            }
            total++;
        });

        const scoreElement = quizElement.querySelector('.score-value');
        if (scoreElement) {
            scoreElement.textContent = `${score}/${total}`;
        }

        this.showToast(`Score: ${score}/${total} (${Math.round((score/total)*100)}%)`, 
                      score === total ? 'success' : 'warning');
    }

    initCopyButtons() {
        document.querySelectorAll('.btn-copy').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const targetId = btn.getAttribute('data-copy-target');
                const target = document.getElementById(targetId);
                
                if (target) {
                    try {
                        await navigator.clipboard.writeText(target.textContent);
                        this.showToast('Copié dans le presse-papier', 'success');
                    } catch (err) {
                        // Fallback pour les anciens navigateurs
                        const textArea = document.createElement('textarea');
                        textArea.value = target.textContent;
                        document.body.appendChild(textArea);
                        textArea.select();
                        document.execCommand('copy');
                        document.body.removeChild(textArea);
                        this.showToast('Copié dans le presse-papier', 'success');
                    }
                }
            });
        });
    }

    initAccordions() {
        document.querySelectorAll('details').forEach(details => {
            details.addEventListener('toggle', (e) => {
                const summary = details.querySelector('summary');
                if (summary) {
                    const icon = summary.querySelector('.chevron');
                    if (icon) {
                        icon.style.transform = details.open ? 'rotate(180deg)' : 'rotate(0deg)';
                    }
                }
            });
        });
    }

    initForms() {
        document.querySelectorAll('input[type="text"], textarea').forEach(input => {
            const storageKey = `module-${this.currentModule.id}-${input.id}`;
            const savedValue = localStorage.getItem(storageKey);
            
            if (savedValue) {
                input.value = savedValue;
            }
            
            input.addEventListener('input', (e) => {
                localStorage.setItem(storageKey, e.target.value);
                this.updateProgressDisplay();
            });
        });
    }

    loadModuleDocs() {
        const docs = [
            { name: 'Guide du formateur', type: 'pdf', size: '1.2 MB', icon: 'file-pdf' },
            { name: 'Présentation PowerPoint', type: 'pptx', size: '3.4 MB', icon: 'file-powerpoint' },
            { name: 'Workbook participant', type: 'docx', size: '850 KB', icon: 'file-word' },
            { name: 'Grille d\'évaluation', type: 'xlsx', size: '450 KB', icon: 'file-excel' },
            { name: 'Checklist qualité', type: 'txt', size: '120 KB', icon: 'file-alt' }
        ];

        this.elements.docsList.innerHTML = docs.map(doc => `
            <div class="doc-item">
                <i class="fas fa-${doc.icon}"></i>
                <div>
                    <strong>${doc.name}</strong>
                    <small>${doc.size}</small>
                </div>
                <button class="btn-download" title="Télécharger">
                    <i class="fas fa-download"></i>
                </button>
            </div>
        `).join('');

        // Ajouter les événements de téléchargement
        document.querySelectorAll('.btn-download').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.showToast('Téléchargement simulé', 'info');
            });
        });

        // Ajouter les événements de clic sur les documents
        document.querySelectorAll('.doc-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.classList.contains('btn-download')) {
                    this.showToast('Prévisualisation du document', 'info');
                }
            });
        });
    }

    renderModulesList() {
        this.elements.modulesList.innerHTML = this.modules.map(module => {
            const progress = this.userProgress[module.id] || { progress: 0 };
            const isBookmarked = this.bookmarks.has(module.id);
            const isActive = this.currentModule && this.currentModule.id === module.id;
            
            return `
                <div class="module-item ${isActive ? 'active' : ''}" data-module-id="${module.id}">
                    <div class="module-icon">
                        <i class="fas fa-${module.isAnnex ? 'folder' : 'calendar-week'}"></i>
                    </div>
                    <div class="module-info">
                        <strong>${module.isAnnex ? module.title : `Semaine ${module.week}`}</strong>
                        <small>${module.title}</small>
                    </div>
                    <div class="module-status">
                        ${progress.progress >= 100 ? 
                            '<i class="fas fa-check-circle text-success"></i>' : 
                            `<div class="mini-progress" style="width: ${progress.progress}%"></div>`
                        }
                        ${isBookmarked ? '<i class="fas fa-bookmark text-gold ml-1"></i>' : ''}
                    </div>
                </div>
            `;
        }).join('');

        // Ajouter les événements de clic
        document.querySelectorAll('.module-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const moduleId = item.getAttribute('data-module-id');
                this.loadModule(moduleId);
            });
        });
    }

    updateModuleListSelection() {
        document.querySelectorAll('.module-item').forEach(item => {
            const moduleId = item.getAttribute('data-module-id');
            if (moduleId === this.currentModule?.id) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
    }

    updateProgressDisplay() {
        if (!this.currentModule) return;

        const progress = this.userProgress[this.currentModule.id] || { progress: 0 };
        const progressValue = progress.progress;
        
        // Barre de progression
        this.elements.moduleProgressBar.style.width = `${progressValue}%`;
        
        // Texte
        this.elements.progressText.textContent = `${progressValue}% complété`;
        
        // Détail (checklists/quiz)
        const checkboxes = document.querySelectorAll('.checklist input[type="checkbox"]');
        const checked = document.querySelectorAll('.checklist input[type="checkbox"]:checked');
        const quizzes = document.querySelectorAll('.quiz');
        const answeredQuizzes = Array.from(quizzes).filter(quiz => {
            const quizId = quiz.querySelector('input[type="radio"]')?.getAttribute('name');
            return quizId && progress.quizzes?.[quizId];
        }).length;
        
        const totalItems = checkboxes.length + quizzes.length;
        const completedItems = checked.length + answeredQuizzes;
        this.elements.progressDetail.textContent = `${completedItems}/${totalItems} éléments`;
        
        // Mettre à jour l'état du bouton "Terminer"
        const btnComplete = document.getElementById('btnComplete');
        if (progressValue >= 100) {
            btnComplete.classList.add('completed');
            btnComplete.innerHTML = '<i class="fas fa-check-circle"></i> Terminé';
        } else {
            btnComplete.classList.remove('completed');
            btnComplete.innerHTML = '<i class="fas fa-check-circle"></i> Marquer comme terminé';
        }
    }

    updateGlobalProgress() {
        if (this.modules.length === 0) return;

        const totalProgress = this.modules.reduce((sum, module) => {
            const progress = this.userProgress[module.id] || { progress: 0 };
            return sum + progress.progress;
        }, 0);

        const averageProgress = Math.round(totalProgress / this.modules.length);
        
        // Mettre à jour la variable CSS pour l'animation
        document.documentElement.style.setProperty('--progress', averageProgress / 100);
        
        // Mettre à jour l'affichage
        const progressValue = document.querySelector('.progress-value');
        if (progressValue) {
            progressValue.textContent = `${averageProgress}%`;
        }
        
        // Mettre à jour le cercle SVG
        const progressFill = document.querySelector('.progress-fill');
        if (progressFill) {
            const circumference = 2 * Math.PI * 26;
            const offset = circumference - (averageProgress / 100) * circumference;
            progressFill.style.strokeDashoffset = offset;
        }
    }

    updateNavigationButtons() {
        if (!this.currentModule) return;

        const currentIndex = this.modules.findIndex(m => m.id === this.currentModule.id);
        
        this.elements.btnPrev.disabled = currentIndex === 0;
        this.elements.btnNext.disabled = currentIndex === this.modules.length - 1;
    }

    updateBookmarkButton() {
        if (!this.currentModule) return;

        const isBookmarked = this.bookmarks.has(this.currentModule.id);
        const icon = this.elements.btnBookmark.querySelector('i');
        
        if (isBookmarked) {
            icon.classList.remove('far');
            icon.classList.add('fas');
            this.elements.btnBookmark.title = 'Retirer des favoris';
        } else {
            icon.classList.remove('fas');
            icon.classList.add('far');
            this.elements.btnBookmark.title = 'Ajouter aux favoris';
        }
    }

    setupEventListeners() {
        // Navigation
        this.elements.btnPrev.addEventListener('click', () => this.navigate(-1));
        this.elements.btnNext.addEventListener('click', () => this.navigate(1));
        
        // Thème
        this.elements.btnTheme.addEventListener('click', () => this.toggleTheme());
        
        // Documents
        this.elements.btnToggleDocs.addEventListener('click', () => this.toggleDocsPanel());
        this.elements.btnCloseDocs.addEventListener('click', () => this.toggleDocsPanel(false));
        
        // Bookmark
        this.elements.btnBookmark.addEventListener('click', () => this.toggleBookmark());
        
        // Notes
        this.elements.btnNotes.addEventListener('click', () => this.openNotesModal());
        
        // Compléter module
        this.elements.btnComplete.addEventListener('click', () => this.completeModule());
        
        // Progression
        this.elements.btnResetProgress.addEventListener('click', () => this.resetModuleProgress());
        this.elements.btnSaveProgress.addEventListener('click', () => this.saveUserData());
        
        // Recherche
        this.elements.searchInput.addEventListener('input', (e) => this.searchModules(e.target.value));
        
        // Gestionnaire d'erreurs global
        window.addEventListener('error', (e) => {
            console.error('Erreur globale:', e.error);
            this.showToast('Une erreur est survenue', 'error');
        });
        
        // Sauvegarde avant déchargement
        window.addEventListener('beforeunload', () => {
            this.saveUserData();
        });
    }

    navigate(direction) {
        if (!this.currentModule) return;

        const currentIndex = this.modules.findIndex(m => m.id === this.currentModule.id);
        const newIndex = currentIndex + direction;
        
        if (newIndex >= 0 && newIndex < this.modules.length) {
            this.loadModule(this.modules[newIndex].id);
        }
    }

    setupTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        
        const icon = this.elements.btnTheme.querySelector('i');
        icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        
        const icon = this.elements.btnTheme.querySelector('i');
        icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        
        this.showToast(`Mode ${newTheme === 'dark' ? 'sombre' : 'clair'} activé`, 'info');
    }

    toggleDocsPanel(show) {
        const docsPanel = document.getElementById('docsPanel');
        if (typeof show === 'undefined') {
            show = !docsPanel.classList.contains('active');
        }
        
        if (show) {
            docsPanel.classList.add('active');
        } else {
            docsPanel.classList.remove('active');
        }
    }

    toggleBookmark() {
        if (!this.currentModule) return;
        
        if (this.bookmarks.has(this.currentModule.id)) {
            this.bookmarks.delete(this.currentModule.id);
            this.showToast('Retiré des favoris', 'info');
        } else {
            this.bookmarks.add(this.currentModule.id);
            this.showToast('Ajouté aux favoris', 'success');
        }
        
        this.saveUserData();
        this.updateBookmarkButton();
        this.renderModulesList();
    }

    openNotesModal() {
        if (!this.currentModule) return;
        
        const modal = document.getElementById('notesModal');
        const textarea = document.getElementById('notesTextarea');
        const btnClear = document.getElementById('btnClearNotes');
        const btnSave = document.getElementById('btnSaveNotes');
        const modalClose = modal.querySelector('.modal-close');
        
        // Charger les notes existantes
        textarea.value = this.userNotes[this.currentModule.id] || '';
        
        // Ouvrir le modal
        modal.classList.add('active');
        
        // Gestionnaires d'événements
        const closeModal = () => {
            modal.classList.remove('active');
        };
        
        modalClose.onclick = closeModal;
        btnClear.onclick = () => {
            textarea.value = '';
        };
        btnSave.onclick = () => {
            this.userNotes[this.currentModule.id] = textarea.value;
            this.saveUserData();
            this.showToast('Notes enregistrées', 'success');
            closeModal();
        };
        
        // Fermer en cliquant à l'extérieur
        modal.onclick = (e) => {
            if (e.target === modal) {
                closeModal();
            }
        };
        
        // Fermer avec Échap
        document.addEventListener('keydown', function handleEscape(e) {
            if (e.key === 'Escape') {
                closeModal();
                document.removeEventListener('keydown', handleEscape);
            }
        });
    }

    completeModule() {
        if (!this.currentModule) return;
        
        const progress = this.userProgress[this.currentModule.id] || { progress: 0 };
        
        if (progress.progress >= 100) {
            // Réinitialiser
            progress.progress = 0;
            progress.checklists = {};
            progress.quizzes = {};
            this.showToast('Module réinitialisé', 'info');
        } else {
            // Marquer comme terminé
            progress.progress = 100;
            
            // Cocher toutes les checklists
            const checkboxes = document.querySelectorAll('.checklist input[type="checkbox"]');
            checkboxes.forEach(cb => cb.checked = true);
            
            // Répondre à tous les quiz (première option)
            document.querySelectorAll('.quiz input[type="radio"]').forEach((radio, index) => {
                if (index % 3 === 0) { // Première option de chaque question
                    radio.checked = true;
                }
            });
            
            this.showToast('Module marqué comme terminé', 'success');
        }
        
        this.userProgress[this.currentModule.id] = progress;
        this.saveUserData();
        this.updateProgressDisplay();
        this.updateGlobalProgress();
        this.updateModuleHeader();
        this.renderModulesList();
    }

    resetModuleProgress() {
        if (!this.currentModule) return;
        
        if (confirm('Voulez-vous vraiment réinitialiser toute la progression de ce module ?')) {
            delete this.userProgress[this.currentModule.id];
            this.saveUserData();
            
            // Réinitialiser l'interface
            document.querySelectorAll('.checklist input[type="checkbox"]').forEach(cb => cb.checked = false);
            document.querySelectorAll('.quiz input[type="radio"]').forEach(radio => radio.checked = false);
            document.querySelectorAll('input[type="text"], textarea').forEach(input => {
                const storageKey = `module-${this.currentModule.id}-${input.id}`;
                localStorage.removeItem(storageKey);
                input.value = '';
            });
            
            this.updateProgressDisplay();
            this.updateGlobalProgress();
            this.updateModuleHeader();
            this.renderModulesList();
            
            this.showToast('Progression réinitialisée', 'info');
        }
    }

    searchModules(query) {
        if (!query.trim()) {
            this.renderModulesList();
            return;
        }
        
        const filteredModules = this.modules.filter(module => {
            const searchText = `${module.title} ${module.description} ${module.tags?.join(' ')}`.toLowerCase();
            return searchText.includes(query.toLowerCase());
        });
        
        this.elements.modulesList.innerHTML = filteredModules.map(module => {
            const progress = this.userProgress[module.id] || { progress: 0 };
            const isBookmarked = this.bookmarks.has(module.id);
            
            return `
                <div class="module-item" data-module-id="${module.id}">
                    <div class="module-icon">
                        <i class="fas fa-${module.isAnnex ? 'folder' : 'calendar-week'}"></i>
                    </div>
                    <div class="module-info">
                        <strong>${module.isAnnex ? module.title : `Semaine ${module.week}`}</strong>
                        <small>${module.title}</small>
                    </div>
                    <div class="module-status">
                        ${progress.progress >= 100 ? 
                            '<i class="fas fa-check-circle text-success"></i>' : 
                            `<div class="mini-progress" style="width: ${progress.progress}%"></div>`
                        }
                        ${isBookmarked ? '<i class="fas fa-bookmark text-gold ml-1"></i>' : ''}
                    </div>
                </div>
            `;
        }).join('');
        
        // Réajouter les événements
        document.querySelectorAll('.module-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const moduleId = item.getAttribute('data-module-id');
                this.loadModule(moduleId);
                this.elements.searchInput.value = '';
                this.renderModulesList();
            });
        });
    }

    showToast(message, type = 'info') {
        const toastContainer = document.getElementById('toastContainer');
        const toastId = 'toast-' + Date.now();
        
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.id = toastId;
        toast.innerHTML = `
            <i class="fas fa-${icons[type]}"></i>
            <div class="toast-content">
                <div class="toast-title">${type.charAt(0).toUpperCase() + type.slice(1)}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        toastContainer.appendChild(toast);
        
        // Afficher le toast
        setTimeout(() => toast.classList.add('show'), 10);
        
        // Fermer automatiquement après 5 secondes
        const autoClose = setTimeout(() => {
            this.closeToast(toastId);
        }, 5000);
        
        // Bouton de fermeture
        toast.querySelector('.toast-close').addEventListener('click', () => {
            clearTimeout(autoClose);
            this.closeToast(toastId);
        });
        
        // Fermer au clic
        toast.addEventListener('click', (e) => {
            if (!e.target.closest('.toast-close')) {
                clearTimeout(autoClose);
                this.closeToast(toastId);
            }
        });
    }

    closeToast(toastId) {
        const toast = document.getElementById(toastId);
        if (toast) {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }
    }

    showError(message) {
        this.elements.moduleContent.innerHTML = `
            <div class="content-section">
                <div class="error-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h2>Erreur</h2>
                    <p>${message}</p>
                    <button class="btn-primary" onclick="location.reload()">
                        <i class="fas fa-redo"></i> Recharger
                    </button>
                </div>
            </div>
        `;
    }
}

// Initialiser l'application
document.addEventListener('DOMContentLoaded', () => {
    window.formationApp = new FormationIAApp();
});

// Exporter certaines fonctions pour le débogage
window.debugApp = {
    getProgress: () => window.formationApp?.userProgress,
    resetAll: () => {
        localStorage.clear();
        location.reload();
    },
    exportData: () => {
        const data = {
            progress: window.formationApp?.userProgress,
            notes: window.formationApp?.userNotes,
            bookmarks: Array.from(window.formationApp?.bookmarks || [])
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `formation-ia-progress-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }
};